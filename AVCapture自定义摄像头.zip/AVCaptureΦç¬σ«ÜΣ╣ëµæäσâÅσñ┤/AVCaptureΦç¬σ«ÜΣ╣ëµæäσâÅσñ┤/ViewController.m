//
//  ViewController.m
//  AVCapture自定义摄像头
//
//  Created by admin on 2018/7/28.
//  Copyright © 2018年 admin. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

#define Resolution_Ratio SCREEN_WIDTH/375.f     //分辨率系数
#define kSCREEN [UIScreen mainScreen]
#define SCREEN_WIDTH  CGRectGetWidth([kSCREEN bounds])
#define SCREEN_HEIGHT CGRectGetHeight([kSCREEN bounds])

@interface ViewController ()<AVCaptureVideoDataOutputSampleBufferDelegate,AVCapturePhotoCaptureDelegate>  //弱光状态代理, 拍照的代理
// 主要用来获取iPhone一些关于相机设备的属性, 它代表抽象的硬件设备(如前置摄像头，后置摄像头等)
@property (nonatomic, strong)AVCaptureDevice *device;
// AVCaptureSession对象来执行输入设备和输出设备之间的数据传递, 它是input和output的桥梁。它协调着input到output的数据传输。
@property (nonatomic, strong)AVCaptureSession *session;
// AVCaptureDeviceInput对象是输入流, 它代表视频输入流
@property (nonatomic, strong)AVCaptureDeviceInput *videoInput;
// AVCaptureVideoDataOutput对象是输出流, 它代表视频输出流. 获取视频实时数据流(对视频进行实时处理)
@property (nonatomic, strong)AVCaptureVideoDataOutput *dataOutput;
// 照片输出流对象, 它代表输出数据,管理着输出到一个图像。AVCaptureStillImageOutput在iOS10以后废弃了
@property (nonatomic, strong)AVCapturePhotoOutput *photoOutput;
// 放置预览图层的View
@property (nonatomic, strong)UIView *cameraShowView;
// 预览图层，来显示照相机拍摄到的画面
@property (nonatomic, strong)AVCaptureVideoPreviewLayer *previewLayer;


// 切换前后镜头的按钮, 未使用
@property (nonatomic, strong)UIButton *toggleButton;
// 拍照按钮
@property (nonatomic, strong)UIButton *shutterButton;
// 拍照按钮
@property (nonatomic, strong) UIButton *photoButton;
// 闪光灯按钮
@property (nonatomic, strong) UIButton *lightButton;
// 用来展示拍照获取的照片
@property (nonatomic, strong)UIImageView *imageShowView;
// 对焦效果view
@property (nonatomic, strong)UIView *focusView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //创建AVCaptureSession
    [self initialSession];
    //加载放置预览图层的View
    [self initCameraShowView];
    //创建底部UI
    [self configView];
    
}

//创建控件
- (void)configView
{
    UIView *downView = [[UIView alloc] init];
    downView.frame = CGRectMake(0, SCREEN_HEIGHT-90*Resolution_Ratio, SCREEN_WIDTH, 90*Resolution_Ratio);
    downView.backgroundColor = [UIColor grayColor];
    [self.view addSubview:downView];
    
    self.shutterButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.shutterButton.frame = CGRectMake(50*Resolution_Ratio, 20*Resolution_Ratio, 60*Resolution_Ratio, 60*Resolution_Ratio);
    self.shutterButton.center = CGPointMake(downView.frame.size.width/2, downView.frame.size.height/2);
    self.shutterButton.backgroundColor = [UIColor cyanColor];
    [self.shutterButton setTitle:@"拍照" forState:UIControlStateNormal];
    [self.shutterButton addTarget:self action:@selector(shutterCamera) forControlEvents:UIControlEventTouchUpInside];
    self.shutterButton.layer.cornerRadius = 30*Resolution_Ratio;
    self.shutterButton.layer.masksToBounds = YES;
    [downView addSubview:self.shutterButton];
    
    self.photoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.photoButton.frame = CGRectMake(50*Resolution_Ratio, 30*Resolution_Ratio, 40*Resolution_Ratio, 40*Resolution_Ratio);
    [self.photoButton setTitle:@"切换镜头" forState:0];
    [self.photoButton setImage:[UIImage imageNamed:@"qiehuan"] forState:0];
    [self.photoButton addTarget:self action:@selector(toggleCamera) forControlEvents:UIControlEventTouchUpInside];
    [downView addSubview:self.photoButton];
    
    self.lightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.lightButton.frame = CGRectMake(SCREEN_WIDTH-90*Resolution_Ratio, 30*Resolution_Ratio, 40*Resolution_Ratio, 40*Resolution_Ratio);
    [self.lightButton setTitle:@"闪光灯" forState:0];
    [self.lightButton setImage:[UIImage imageNamed:@"shanguangdeng"] forState:0];
    [self.lightButton addTarget:self action:@selector(torchButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [downView addSubview:self.lightButton];
    
    self.imageShowView = [[UIImageView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-190*Resolution_Ratio, 100*Resolution_Ratio, 100*Resolution_Ratio)];
    self.imageShowView.contentMode = UIViewContentModeScaleToFill;
    self.imageShowView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.imageShowView];
    
    /*
     * 对焦手势
     */
    UITapGestureRecognizer *_tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(focusGesture:)];
    [self.cameraShowView addGestureRecognizer:_tapGesture];
    
    /*
     * 对焦效果view
     */
    self.focusView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 80, 80)];
    _focusView.layer.borderWidth = 1.0;
    _focusView.layer.borderColor =[UIColor greenColor].CGColor;
    _focusView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_focusView];
    _focusView.hidden = YES;
}

#pragma mark 点击屏幕聚焦
- (void)focusGesture:(UITapGestureRecognizer*)gesture{
    CGPoint point = [gesture locationInView:gesture.view];   //获得点击的位置
    [self focusAtPoint:point];
}

- (void)focusAtPoint:(CGPoint)point{
    CGSize size = self.cameraShowView.bounds.size;
    CGPoint focusPoint = CGPointMake( point.y /size.height ,1-point.x/size.width );   //聚焦点位置
    NSError *error;
    if ([_device lockForConfiguration:&error]) {
        if ([_device isFocusModeSupported:AVCaptureFocusModeAutoFocus]) {
            [_device setFocusPointOfInterest:focusPoint];     //镜头聚焦在点击位置
            [_device setFocusMode:AVCaptureFocusModeAutoFocus];   //设置镜头自动调焦模式
        }
        [_device unlockForConfiguration];
    }
    /*
     * 下面是手触碰屏幕后对焦的效果
     */
    _focusView.center = point;
    _focusView.hidden = NO;
    
    [UIView animateWithDuration:0.3 animations:^{
        _focusView.transform = CGAffineTransformMakeScale(1.25, 1.25);
    }completion:^(BOOL finished) {
        [UIView animateWithDuration:0.5 animations:^{
            _focusView.transform = CGAffineTransformIdentity;
        } completion:^(BOOL finished) {
            _focusView.hidden = YES;
        }];
    }];
}

#pragma mark 初始化session
- (void)initialSession
{
    self.session = [[AVCaptureSession alloc] init];
    
    self.device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    self.videoInput = [[AVCaptureDeviceInput alloc] initWithDevice:[self backCamera] error:nil];
    
    self.photoOutput = [[AVCapturePhotoOutput alloc] init];
    // 这是输出流的设置参数AVVideoCodecJPEG参数表示以JPEG的图片格式输出图片
    // NSDictionary *setDic = @{AVVideoCodecKey:AVVideoCodecJPEG};
    AVCapturePhotoSettings *outputSettings = [AVCapturePhotoSettings photoSettings];  //默认是JPEG图片
    [self.photoOutput setPhotoSettingsForSceneMonitoring:outputSettings];

    //添加视频输入源
    if ([self.session canAddInput:self.videoInput]) {
        [self.session addInput:self.videoInput];
    }
    
    //添加图片输出源
    if ([self.session canAddOutput:self.photoOutput]) {
        [self.session addOutput:self.photoOutput];
    }
    
    //添加视频输出源
    if ([self.session canAddOutput:self.dataOutput]) {
        [self.session addOutput:self.dataOutput];
    }
}

#pragma mark 初始化cameraShowView
- (void)initCameraShowView
{
    self.cameraShowView = [[UIView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:self.cameraShowView];
}


// 这是获取前后摄像头对象的方法
- (AVCaptureDevice *)cameraWithPosition:(AVCaptureDevicePosition)position
{
    AVCaptureDeviceDiscoverySession *devicesIOS10 = [AVCaptureDeviceDiscoverySession  discoverySessionWithDeviceTypes:@[AVCaptureDeviceTypeBuiltInWideAngleCamera] mediaType:AVMediaTypeVideo position:position];
    NSArray *devicesIOS  = devicesIOS10.devices;
    //NSArray *devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];   //iOS10之前方法  之后用新方法
    for (AVCaptureDevice *device in devicesIOS) {
        if (device.position == position) {
            return device;
        }
    }
    return nil;
}

//前置摄像头
- (AVCaptureDevice *)frontCamera
{
    return [self cameraWithPosition:AVCaptureDevicePositionFront];
}

//后置摄像头
- (AVCaptureDevice *)backCamera
{
    return [self cameraWithPosition:AVCaptureDevicePositionBack];
}

#pragma mark 切换镜头
- (void)toggleCamera
{
    NSUInteger cameraCount = [[AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo] count];
    if (cameraCount > 1) {
        NSError *error;
        AVCaptureDeviceInput *newVideoInput;
        AVCaptureDevicePosition position = [[_videoInput device] position];
        if (position == AVCaptureDevicePositionBack) {
            newVideoInput = [[AVCaptureDeviceInput alloc] initWithDevice:[self frontCamera] error:&error];
        } else if (position == AVCaptureDevicePositionFront) {
            newVideoInput = [[AVCaptureDeviceInput alloc] initWithDevice:[self backCamera] error:&error];
        } else {
            return;
        }
        
        if (newVideoInput != nil) {
            [self.session beginConfiguration];
            [self.session removeInput:self.videoInput];
            if ([self.session canAddInput:newVideoInput]) {
                [self.session addInput:newVideoInput];
                self.videoInput = newVideoInput;
            } else {
                [self.session addInput:self.videoInput];
            }
            
            [self.session commitConfiguration];
        } else if (error) {
            NSLog(@"toggle carema failed, error = %@", error);
        }
    }
}

#pragma mark 生命周期
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //加载预览图层
    [self setUpCameraLayer];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if (self.session) {
        [self.session startRunning];   //开始
    }
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    if (self.session) {
        [self.session stopRunning];    //停止
    }
}

//将预览图层添加到之前生成的View上
- (void)setUpCameraLayer
{
    if (self.previewLayer == nil) {
        self.previewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:self.session];
        UIView * view = self.cameraShowView;
        CALayer * viewLayer = [view layer];
        // UIView的clipsToBounds属性和CALayer的setMasksToBounds属性表达的意思是一致的,决定子视图的显示范围。当取值为YES的时候，剪裁超出父视图范围的子视图部分，当取值为NO时，不剪裁子视图。
        [viewLayer setMasksToBounds:YES];
        CGRect bounds = [view bounds];
        [self.previewLayer setFrame:bounds];
        [self.previewLayer setVideoGravity:AVLayerVideoGravityResizeAspect];
        [viewLayer addSublayer:self.previewLayer];
    }
}

#pragma mark 这是拍照按钮的方法
- (void)shutterCamera
{
    //默认是JPEG图片   可以选择其他格式
    AVCapturePhotoSettings *outputSettings = [AVCapturePhotoSettings photoSettings];
    [self.photoOutput capturePhotoWithSettings:outputSettings delegate:self];
}

#pragma mark AVCapturePhotoCaptureDelegate  拍照的代理方法
- (void)captureOutput:(AVCapturePhotoOutput *)captureOutput didFinishProcessingPhotoSampleBuffer:(nullable CMSampleBufferRef)photoSampleBuffer previewPhotoSampleBuffer:(nullable CMSampleBufferRef)previewPhotoSampleBuffer resolvedSettings:(AVCaptureResolvedPhotoSettings *)resolvedSettings bracketSettings:(nullable AVCaptureBracketedStillImageSettings *)bracketSettings error:(nullable NSError *)error {
    
    NSData *data = [AVCapturePhotoOutput JPEGPhotoDataRepresentationForJPEGSampleBuffer:photoSampleBuffer previewPhotoSampleBuffer:previewPhotoSampleBuffer];
    UIImage *image = [UIImage imageWithData:data];
    self.imageShowView.image = image;
    //UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);  //保存图片方法
}

- (void)image: (UIImage *) image didFinishSavingWithError: (NSError *) error contextInfo: (void *) contextInfo {
    NSString *msg = nil ;
    if(error != NULL){
        msg = @"保存图片失败" ;
    }else{
        msg = @"保存图片成功" ;
    }
}

#pragma mark 相册点击方法
- (void)imageButtonClick:(id)sender {
    
}


#pragma mark 手电筒点击方法
- (void)torchButtonClick:(UIButton *)button {
    Class captureDeviceClass = NSClassFromString(@"AVCaptureDevice");
    
    if (captureDeviceClass != nil) {
        AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];  //控制手电筒开关
        AVCapturePhotoSettings *photoSettings = [[AVCapturePhotoSettings alloc] init];   //控制闪光灯开关
        //必须判定是否有手电筒&闪光灯，否则如果没有闪光灯会崩溃
        if ([device hasTorch] && [device hasFlash]){
            //修改前必须先锁定
            [device lockForConfiguration:nil];
            if (button.selected) {
                [device setTorchMode:AVCaptureTorchModeOff];      //关闭手电筒
                photoSettings.flashMode = AVCaptureFlashModeOff;  //关闭闪光灯
            } else {
                [device setTorchMode:AVCaptureTorchModeOn];       //开启手电筒
                photoSettings.flashMode = AVCaptureFlashModeOn;   //开启闪光灯
            }
            button.selected = !button.selected;
            [device unlockForConfiguration];
        }
    }
}

#pragma mark- AVCaptureVideoDataOutputSampleBufferDelegate的方法   弱光感应
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection {
    
    CFDictionaryRef metadataDict = CMCopyDictionaryOfAttachments(NULL,sampleBuffer, kCMAttachmentMode_ShouldPropagate);
    NSDictionary *metadata = [[NSMutableDictionary alloc] initWithDictionary:(__bridge NSDictionary*)metadataDict];
    CFRelease(metadataDict);
    NSDictionary *exifMetadata = [[metadata objectForKey:(NSString *)kCGImagePropertyExifDictionary] mutableCopy];
    float brightnessValue = [[exifMetadata objectForKey:(NSString *)kCGImagePropertyExifBrightnessValue] floatValue];
    
    NSLog(@"brightnessValue：%f",brightnessValue);
    
    // 根据brightnessValue的值来打开和关闭闪光灯
    Class captureDeviceClass = NSClassFromString(@"AVCaptureDevice");
    if ((brightnessValue < 0) && captureDeviceClass != nil) {
        //NSLog(@"弱光状态");
    }else if((brightnessValue > 0) && captureDeviceClass != nil) {
        //NSLog(@"正常状态");
    }
    
}



#pragma mark 懒加载方法
- (AVCaptureVideoDataOutput *)dataOutput
{
    if (!_dataOutput) {
        _dataOutput = [[AVCaptureVideoDataOutput alloc] init];
        _dataOutput.alwaysDiscardsLateVideoFrames = YES;
        dispatch_queue_t queue = dispatch_queue_create("cameraQueue", NULL);
        [_dataOutput setSampleBufferDelegate:self queue:queue];
        NSString* key = (NSString*)kCVPixelBufferPixelFormatTypeKey;
        NSNumber* value = [NSNumber numberWithUnsignedInt:kCVPixelFormatType_32BGRA];
        NSDictionary* videoSettings = [NSDictionary dictionaryWithObject:value forKey:key];
        [_dataOutput setVideoSettings:videoSettings];
    }
    return _dataOutput;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
